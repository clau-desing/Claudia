package com.regalado.service;


import com.regalado.entity.Infraccion;
import java.util.List;
import org.springframework.data.domain.Pageable;

public interface InfraccionService {
    public List<Infraccion> findAll(Pageable page);
    public List<Infraccion> findAll();
    public List<Infraccion> findByDni(String dni, Pageable page);
    public Infraccion findById(int id);
    public Infraccion save(Infraccion infraccion);
    public void delete(int id);
}
