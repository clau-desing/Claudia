package com.regalado.service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.regalado.entity.Infraccion;
import com.regalado.exception.GeneralException;
import com.regalado.exception.NoDataFoundException;
import com.regalado.exception.ValidateException;
import com.regalado.repository.InfraccionRepository;
import com.regalado.service.InfraccionService;
import com.regalado.validator.InfraccionValidator;

@Service
public class InfraccionServiceImpl implements InfraccionService {

    @Autowired
    private InfraccionRepository repository;

    @Override
    @Transactional(readOnly = true)
    public List<Infraccion> findAll(Pageable page) {
        try {
            List<Infraccion> registros = repository.findAll(page).toList();
            return registros;
        } catch (ValidateException | NoDataFoundException e) {
            throw e;
        } catch (GeneralException e) {
            throw new GeneralException("Error del servidor");
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<Infraccion> findByDni(String dni, Pageable page) {
        try {
            List<Infraccion> registros = repository.findByDniContaining(dni, page);
            return registros;
        } catch (ValidateException | NoDataFoundException e) {
            throw e;
        } catch (GeneralException e) {
            throw new GeneralException("Error del servidor");
        }
    }

    @Override
    @Transactional(readOnly = true)
    public Infraccion findById(int id) {
        try {
            Infraccion registro = repository.findById(id)
                    .orElseThrow(() -> new NoDataFoundException("No existe un registro con ese ID"));
            return registro;
        } catch (ValidateException | NoDataFoundException e) {
            throw e;
        } catch (GeneralException e) {
            throw new GeneralException("Error del servidor");
        }
    }

    @Override
    @Transactional
    public Infraccion save(Infraccion infraccion) {
        try {
            InfraccionValidator.save(infraccion);
            // Nuevo registro
            if (infraccion.getId() == 0) {
                Infraccion nuevo = repository.save(infraccion);
                return nuevo;
            }
            // Editar registro
            Infraccion registro = repository.findById(infraccion.getId())
                    .orElseThrow(() -> new NoDataFoundException("No existe un registro con ese ID"));
            registro.setDni(infraccion.getDni());
            registro.setFecha(infraccion.getFecha());
            registro.setPlaca(infraccion.getPlaca());
            registro.setInfraccion(infraccion.getInfraccion());
            registro.setDescripcion(infraccion.getDescripcion());
            repository.save(registro);
            return registro;
        } catch (ValidateException | NoDataFoundException e) {
            throw e;
        } catch (GeneralException e) {
            throw new GeneralException("Error del servidor");
        }
    }

    @Override
    @Transactional
    public void delete(int id) {
        try {
            Infraccion registro = repository.findById(id)
                    .orElseThrow(() -> new NoDataFoundException("No existe un registro con ese ID"));
            repository.delete(registro);
        } catch (ValidateException | NoDataFoundException e) {
            throw e;
        } catch (GeneralException e) {
            throw new GeneralException("Error del servidor");
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<Infraccion> findAll() {
        try {
            List<Infraccion> registros = repository.findAll();
            return registros;
        } catch (ValidateException | NoDataFoundException e) {
            throw e;
        } catch (GeneralException e) {
            throw new GeneralException("Error del servidor");
        }
    }
}

