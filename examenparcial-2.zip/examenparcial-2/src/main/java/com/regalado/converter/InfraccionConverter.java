package com.regalado.converter;

import com.regalado.dto.InfraccionDto;
import com.regalado.entity.Infraccion;

public class InfraccionConverter extends AbstractConverter<Infraccion, InfraccionDto> {
	
	 @Override
	    public InfraccionDto fromEntity(Infraccion entity) {
	        if (entity == null) return null;
	        return InfraccionDto.builder()
	                .id(entity.getId())
	                .dni(entity.getDni())
	                .fecha(entity.getFecha().toString()) 
	                .placa(entity.getPlaca())
	                .infraccion(entity.getInfraccion())
	                .descripcion(entity.getDescripcion())
	                .createdAt(entity.getCreatedAt().toString())
	                .updatedAt(entity.getUpdatedAt().toString())
	                .build();
	    }

	    @Override
	    public Infraccion fromDTO(InfraccionDto dto) {
	        if (dto == null) return null;
	        return Infraccion.builder()
	                .id(dto.getId())
	                .dni(dto.getDni())
	                .fecha(java.sql.Timestamp.valueOf(dto.getFecha())) 
	                .placa(dto.getPlaca())
	                .infraccion(dto.getInfraccion())
	                .descripcion(dto.getDescripcion())
	                .createdAt(java.sql.Timestamp.valueOf(dto.getCreatedAt())) 
	                .updatedAt(java.sql.Timestamp.valueOf(dto.getUpdatedAt())) 
	                .build();
	    }

}
