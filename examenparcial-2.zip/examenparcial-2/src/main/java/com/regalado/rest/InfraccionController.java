package com.regalado.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.regalado.dto.InfraccionDto;
import com.regalado.converter.InfraccionConverter;
import com.regalado.entity.Infraccion;
import com.regalado.service.InfraccionService;
import com.regalado.util.WrapperResponse;

@RestController
@RequestMapping("/v1/infracciones")
public class InfraccionController {

    @Autowired
    private InfraccionService service;

    @Autowired
    private InfraccionConverter converter;

    @GetMapping
    public ResponseEntity<List<InfraccionDto>> findAll(
            @RequestParam(value = "offset", required = false, defaultValue = "0") int pageNumber,
            @RequestParam(value = "limit", required = false, defaultValue = "5") int pageSize
    ) {
        Pageable page = PageRequest.of(pageNumber, pageSize);
        List<InfraccionDto> infracciones = converter.fromEntity(service.findAll());

        return new WrapperResponse(true, "success", infracciones).createResponse(HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<InfraccionDto> create(@RequestBody InfraccionDto infraccion) {
        Infraccion infraccionEntity = converter.fromDTO(infraccion);
        InfraccionDto registro = converter.fromEntity(service.save(infraccionEntity));
        return new WrapperResponse(true, "success", registro).createResponse(HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InfraccionDto> update(@PathVariable("id") int id, @RequestBody InfraccionDto infraccion) {
        Infraccion infraccionEntity = converter.fromDTO(infraccion);
        InfraccionDto registro = converter.fromEntity(service.save(infraccionEntity));
        return new WrapperResponse(true, "success", registro).createResponse(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity delete(@PathVariable("id") int id) {
        service.delete(id);
        return new WrapperResponse(true, "success", null).createResponse(HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<InfraccionDto> findById(@PathVariable("id") int id) {
        InfraccionDto registro = converter.fromEntity(service.findById(id));
        return new WrapperResponse(true, "success", registro).createResponse(HttpStatus.OK);
    }
}
