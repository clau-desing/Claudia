package com.regalado.controller;

public class MainController {

}
