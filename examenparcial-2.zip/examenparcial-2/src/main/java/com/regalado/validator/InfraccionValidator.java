package com.regalado.validator;

import com.regalado.entity.Infraccion;
import com.regalado.exception.ValidateException;

public class InfraccionValidator {

    public static void save(Infraccion registro) {
        if (registro.getDni() == null || registro.getDni().trim().isEmpty()) {
            throw new ValidateException("El DNI es requerido");
        }
        if (registro.getDni().length() != 8) {
            throw new ValidateException("El DNI debe tener 8 caracteres");
        }

        if (registro.getPlaca() == null || registro.getPlaca().trim().isEmpty()) {
            throw new ValidateException("La placa es requerida");
        }
        if (registro.getPlaca().length() > 7) {
            throw new ValidateException("La placa no debe exceder los 7 caracteres");
        }

        if (registro.getInfraccion() == null || registro.getInfraccion().trim().isEmpty()) {
            throw new ValidateException("La descripción de la infracción es requerida");
        }
        if (registro.getInfraccion().length() > 200) {
            throw new ValidateException("La infracción no debe exceder los 200 caracteres");
        }

        if (registro.getDescripcion() != null && registro.getDescripcion().length() > 255) {
            throw new ValidateException("La descripción no debe exceder los 255 caracteres");
        }
    }
}

